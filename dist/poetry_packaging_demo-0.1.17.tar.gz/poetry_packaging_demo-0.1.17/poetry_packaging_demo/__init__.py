from .util import for_each
