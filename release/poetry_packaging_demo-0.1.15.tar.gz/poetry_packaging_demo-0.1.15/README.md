# poetry-packaging-demo
Demo of a CI pipeline for Python projects that lints, tests and publishes to PyPI with Poetry
